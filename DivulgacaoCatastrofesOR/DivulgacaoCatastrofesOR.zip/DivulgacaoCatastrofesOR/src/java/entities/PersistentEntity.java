package entities;

public interface PersistentEntity {

    public Long getId();

    public void setId(Long id);
}
